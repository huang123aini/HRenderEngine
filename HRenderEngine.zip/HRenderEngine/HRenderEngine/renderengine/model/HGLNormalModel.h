//
//  HNormalModel.h
//  HRenderEngine
//
//  Created by 黄世平 on 17/4/17.
//  Copyright © 2017年 黄世平. All rights reserved.
//

#import "HGLModel.h"

@interface HGLNormalModel : HGLModel

@end
