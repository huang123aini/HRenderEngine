////
////  HImage.h
////  HRenderEngine
////
////  Created by 黄世平 on 17/5/8.
////  Copyright © 2017年 黄世平. All rights reserved.
////
//
//#import <Foundation/Foundation.h>
//
//typedef UIImage HImage;
//
//
//HImage * HImageWithCGImage(CGImageRef image);
//
//
//// CVPixelBufferRef
//HImage * HImageWithCVPixelBuffer(CVPixelBufferRef pixelBuffer);
//CIImage * HImageCIImageWithCVPexelBuffer(CVPixelBufferRef pixelBuffer);
//CGImageRef HImageCGImageWithCVPexelBuffer(CVPixelBufferRef pixelBuffer);
//
//// RGB data buffer
//HImage * HImageWithRGBData(UInt8 * rgb_data, int linesize, int width, int height);
//CGImageRef HImageCGImageWithRGBData(UInt8 * rgb_data, int linesize, int width, int height);
