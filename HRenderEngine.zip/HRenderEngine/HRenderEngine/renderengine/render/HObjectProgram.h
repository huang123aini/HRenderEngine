//
//  HObjectProgram.h
//  HRenderEngine
//
//  Created by 黄世平 on 17/4/18.
//  Copyright © 2017年 黄世平. All rights reserved.
//

#import "HProgram.h"

@interface HObjectProgram : HProgram

-(instancetype)init;

@end
