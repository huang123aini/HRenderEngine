//
//  HCubeNorm.h
//  HRenderEngine
//
//  Created by 黄世平 on 17/5/3.
//  Copyright © 2017年 黄世平. All rights reserved.
//

#import "HRenderObject.h"

@interface HCubeNorm : HRenderObject

-(instancetype)init;

@end
