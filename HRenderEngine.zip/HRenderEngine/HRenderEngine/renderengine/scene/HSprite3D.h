//
//  HSprite3D.h
//  HRenderEngine
//
//  Created by 黄世平 on 17/4/17.
//  Copyright © 2017年 黄世平. All rights reserved.
//

#import "HRenderObject.h"

@interface HSprite3D : HRenderObject

-(instancetype)initWithImage:(UIImage*)image;

@end
