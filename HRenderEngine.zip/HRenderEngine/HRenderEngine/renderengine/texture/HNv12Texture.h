////
////  HNv12Texture.h
////  HRenderEngine
////
////  Created by 黄世平 on 17/5/8.
////  Copyright © 2017年 黄世平. All rights reserved.
////
//
//#import "HTexture.h"
//
//@interface HNv12Texture : HTexture
//
//-(instancetype)initWithContext:(EAGLContext*)context;
//@end
