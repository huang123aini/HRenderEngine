//
//  HMathUtils.h
//  HRenderEngine
//
//  Created by 黄世平 on 17/4/21.
//  Copyright © 2017年 黄世平. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HMathUtils : NSObject

+(void)getGLCoordsFromCGRect:(CGRect) rect Coords:(GLfloat*)coords;

@end
