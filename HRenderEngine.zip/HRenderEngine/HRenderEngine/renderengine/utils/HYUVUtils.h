//
//  HYUVUtils.h
//  HRenderEngine
//
//  Created by 黄世平 on 17/5/8.
//  Copyright © 2017年 黄世平. All rights reserved.
//

#import <Foundation/Foundation.h>


//TODO: HYUVUtils类依赖于FFMPEG

//#import "pixfmt.h"
//#import <HImage.h>
//
//
//int HYUVChannelFilterNeedSize(int linesize, int width, int height, int channel_count);
//
//void HYUVChannelFilter(UInt8 * src, int linesize, int width, int height, UInt8 * dst, size_t dstsize, int channel_count);
//
//HImage * HYUVConvertToImage(UInt8 * src_data[], int src_linesize[], int width, int height, enum AVPixelFormat pixelFormat);
